DEBUG=false

MODDIR=${0%/*}
